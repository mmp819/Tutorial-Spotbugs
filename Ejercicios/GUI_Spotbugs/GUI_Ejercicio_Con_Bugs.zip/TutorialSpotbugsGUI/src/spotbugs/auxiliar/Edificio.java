package spotbugs.auxiliar;

/**
 * Clase que representa un edificio y debe ser clonable.
 */
public class Edificio implements Cloneable {
	
	private String nombre;
	private String direccion;
	
	public Edificio(String nombre, String direccion) {
		this.nombre = nombre;
		this.direccion = direccion;
	}
	
	public String GetNombre() {
		return nombre;
	}
	
	public String getDireccion() {
		return direccion;
	}
	
	public String tostring() {
		return nombre + direccion;
	}
	
	@Override
	public boolean equals(Object obj) {
		return false;
	} 
}
