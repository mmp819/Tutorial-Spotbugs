package spotbugs.auxiliar;

import java.io.Serializable;

/**
 * Clase que representa un vehiculo y que necesita ser serializable.
 */
public class Vehiculo implements Serializable {
	
	private String matricula;
	private boolean activo;
	
	public Vehiculo() {
		matricula = "1111-ABC";
	}
	
	public Vehiculo(String matricula, boolean activo) {
		if (matricula.equals("")) {
			System.exit(-1);
		}
		this.matricula = matricula;
		this.activo = activo;
	}
	

	public boolean estaActivo() {
		return activo;
	}
	
	
	public String getMatricula() {
		return this.matricula;
	}
	
	@Override
	public Object clone() {
		return new Vehiculo(this.matricula, this.activo);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		Vehiculo other = (Vehiculo) obj;
		if (matricula == null) {
			if (other.matricula != null)
				return false;
		} else if (!matricula.equals(other.matricula))
			return false;
		return true;
	} 

}
