package es.unican.calidad;

public class CodigoAnomalo {

	public static void main(String[] args) {
		
		// USELESS OBJECT CREATED
		Number[] arr = new Integer[10];
		arr[0] = 1;
		
		
		// EXCEPTION IS CAUGHT WHEN EXCEPTION IS NOT THROWN
		try {
			System.out.println("C�digo sin excepciones\n");
		} catch (NullPointerException e) {
			System.out.println("No salta nunca la excepci�n \n");
		}
		
		// SWITCH STATEMENT FOUND WHERE DEFAULT CASE IS MISSING
		int s = 1;
		switch(s) {
		case 0:
			System.out.println("Switch");
			break;
		case 1:
			System.out.println("Switch2");
			break;
		}
		
		
		// DOUBLE ASSIGNEMENT FOR LOCAL VARIABLE
		int j = 0;
		if (j == 1) {
			j = 2;
		} else {
			j = 2;
		}
		
		// USELESS NON-EMPTY VOID METHOD		
		while(true) {
		}
		
		
	}
	
	
	

}
