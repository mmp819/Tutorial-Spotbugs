package bugs;


import java.util.Calendar;

public class SegundoBug {
	
	//Codigo vulnerable a ataques.
	private Calendar cd = Calendar.getInstance();	
	
	public Calendar modiCale() {
		cd.setFirstDayOfWeek(1);
		return cd;
	}
}

