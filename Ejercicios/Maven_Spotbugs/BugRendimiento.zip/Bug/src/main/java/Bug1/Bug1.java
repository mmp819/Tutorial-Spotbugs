package Bug1;

public class Bug1 {
	//Paso 1. inicializar la variable
	private String bug;
	
	//Descomentar paso 3.
	//private String getBug() {
		//return bug;
	//}
}
