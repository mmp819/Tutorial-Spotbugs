package bugs;

import java.util.Calendar;

public class PrimerBug {

	//Uso correcto de varios hilos.
	private Calendar cd = Calendar.getInstance();	
	
	public void modiCale() {
		cd.setFirstDayOfWeek(1);
	}
		
}

