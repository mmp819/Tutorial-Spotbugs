package bugs;


import java.util.Calendar;

public class SegundoBug {
	
	//Codigo vulnerable a ataques.
	private Calendar cd = Calendar.getInstance();	
	
	public void modiCale() {
		cd.setFirstDayOfWeek(1);
	}
}

