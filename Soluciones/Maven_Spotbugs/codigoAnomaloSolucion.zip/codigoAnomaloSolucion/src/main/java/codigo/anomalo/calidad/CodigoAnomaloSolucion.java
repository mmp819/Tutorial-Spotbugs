package codigo.anomalo.calidad;

public class CodigoAnomaloSolucion {


	public static void main(String[] args) {
		
		// USELESS OBJECT CREATED
		
		Number[] arr = new Integer[10];
		arr[0] = 1;
		
		for(int i = 0; i < 10; i++) {
			System.out.println(arr[i] + "\n");
		}
		
		// EXCEPTION IS CAUGHT WHEN EXCEPTION IS NOT THROWN
		System.out.println("C�digo sin excepciones\n");
		
		
		// SWITCH STATEMENT FOUND WHERE DEFAULT CASE IS MISSING
		int s = 1;
		switch(s) {
		case 0:
			System.out.println("Switch");
			break;
		case 1:
			System.out.println("Switch2");
			break;
		default:
		}
		
		
		
		// DOUBLE ASSIGNEMENT FOR LOCAL VARIABLE
		int j = 0;
		if (j == 1) {
			j = 2;
		} else {
			
			j = 3;
		}
		
		// USELESS NON-EMPTY VOID METHOD		
		while(true) {
			System.out.println(arr[1] + "\n");
		}
		
		
	}
}
