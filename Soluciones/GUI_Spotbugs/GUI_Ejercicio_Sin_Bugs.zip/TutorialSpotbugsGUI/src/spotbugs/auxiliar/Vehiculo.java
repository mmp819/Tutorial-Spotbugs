package spotbugs.auxiliar;

import java.io.Serializable;

/**
 * Clase que representa un vehiculo y que necesita ser serializable.
 */
public class Vehiculo implements Serializable, Cloneable {
	
	private static final long serialVersionUID = 1L;
	private String matricula;
	private boolean activo;
	
	public Vehiculo() {
		matricula = "1111-ABC";
	}
	
	public Vehiculo(String matricula, boolean activo) {
		if (matricula.equals("")) {
			matricula = "1111-ABC";
		}
		this.matricula = matricula;
		this.activo = activo;
	}
	

	public boolean estaActivo() {
		return activo;
	}
	
	
	public String getMatricula() {
		return this.matricula;
	}
	
	@Override
	public Object clone() {
		Object clone = null;
		try {
			clone = super.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return clone;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (this == obj)
			return true;
		if (getClass() != obj.getClass())
			return false;
		Vehiculo other = (Vehiculo) obj;
		if (matricula == null) {
			if (other.matricula != null)
				return false;
		} else if (!matricula.equals(other.matricula))
			return false;
		return true;
	} 
	
	@Override
	public int hashCode() {
		return matricula.hashCode();
	}

}
