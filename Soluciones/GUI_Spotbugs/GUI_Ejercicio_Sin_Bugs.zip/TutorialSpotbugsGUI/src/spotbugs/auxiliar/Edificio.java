package spotbugs.auxiliar;

/**
 * Clase que representa un edificio y debe ser clonable.
 */
public class Edificio implements Cloneable {
	
	private String nombre;
	private String direccion;
	
	public Edificio(String nombre, String direccion) {
		this.nombre = nombre;
		this.direccion = direccion;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public String getDireccion() {
		return direccion;
	}
	
	@Override
	public String toString() {
		return nombre + direccion;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (this == obj)
			return true;
		if (getClass() != obj.getClass())
			return false;
		Edificio other = (Edificio) obj;
		if (nombre.equals(other.nombre)) {
			return true;
		} else {
			return false;
		}
	} 
	
	@Override
	public int hashCode() {
		return nombre.hashCode();
	}
	
	@Override
	public Object clone() {
		Object clone = null;
		try {
			clone = super.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return clone;
	}
}
