package spotbugs.runner;

import java.util.ArrayList;
import java.util.List;

// import spotbugs.auxiliar.Vehiculo;

/**
 * Clase Runner para el tutorial de uso de la GUI de Spotbugs.
 * 
 * ¿Podras encontrar todos los bugs del proyecto Java?
 */
public class Runner {

	public static void main(String[] args) {
		
		String m1 = "1111-ABC";
		String m2 = "2222-DEF";
		
		if (m1.equals(m2)) {
			System.out.println("Aconsejable cambiar matriculas");
		}
		
		List<String> matriculas = new ArrayList<>();
		
		for (int i = 0; i < matriculas.size(); i++) {
			System.out.println(matriculas.get(i));
		}
		
		//Vehiculo v1 = new Vehiculo(m1, true);
		
		if (m2.equals(m1)) {
			System.out.println("Ahora si has comparado 2 matriculas.");
		}
		
		int numeroMatriculas = Integer.MAX_VALUE;
		
		if (numeroMatriculas == matriculas.size()) {
			System.out.println("La variable coincide con el numero de matriculas");
		}
		
		System.out.println("Suerte con el tutorial!");
		
	}

}
